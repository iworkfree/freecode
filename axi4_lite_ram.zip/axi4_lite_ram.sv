

// AXI4-Lite RAM Module
// module axi4_lite_ram #(axi4_lite_pkg::lut_cfg_t L = '{w: 16, d: 32, pipe: 1, file: "", init: 0}
module axi4_lite_ram #(xaxi4_lite_pkg::xaxi4_lite_cfg_t C='{default: 0}
                    xaxi4_lite_pkg::lut_cfg_t M = '{w: 16, d: 32, pipe: 1, init: 0}
) (
    input  logic          aclk,
    input  logic          aresetn,
    xaxi4_lite_if         axil4
);
    import xaxi4_lite_pkg::*;

// Internal parameters
localparam no_of_registers = 32;
localparam ADDR_WIDTH      = $CLOG2(M.d);  // C.A;           
localparam DATA_WIDTH      = 8 * C.N;          

// Internal register array and signals
logic [M.w-1 : 0] register [M.d-1 : 0];
logic [ADDR_WIDTH-1 : 0] addr;

// FSM state definitions
typedef enum logic [2 : 0] {
    IDLE,
    WRITE_DATA,
    WRITE_RESP,
    READ_DATA
} state_type;

state_type state, next_state;

// Internal signals for handshake and data storage
logic aw_hs, w_hs, ar_hs, r_hs, b_hs;

// Handshake signal declarations (using the new lowercase names)
assign aw_hs = axil4.s_axi_awvalid && axil4.s_axi_awready;
assign w_hs  = axil4.s_axi_wvalid  && axil4.s_axi_wready;
assign ar_hs = axil4.s_axi_arvalid && axil4.s_axi_arready;
assign r_hs  = axil4.s_axi_rvalid  && axil4.s_axi_rready;
assign b_hs  = axil4.s_axi_bvalid  && axil4.s_axi_bready;

// AXI Ready/Valid signal logic
always_comb begin
    axil4.s_axi_awready = 1'b0;
    axil4.s_axi_wready  = 1'b0;
    axil4.s_axi_bvalid  = 1'b0;
    axil4.s_axi_arready = 1'b0;
    axil4.s_axi_rvalid  = 1'b0;
    axil4.s_axi_bresp   = 2'b00; // OKAY response
    axil4.s_axi_rresp   = 2'b00; // OKAY response
    axil4.s_axi_rdata   = '0;

    case (state)
        IDLE: begin
            if (axil4.s_axi_awvalid) axil4.s_axi_awready = 1'b1;
            if (axil4.s_axi_arvalid) axil4.s_axi_arready = 1'b1;
        end
        WRITE_DATA: begin
            axil4.s_axi_wready = 1'b1;
        end
        WRITE_RESP: begin
            axil4.s_axi_bvalid = 1'b1;
        end
        READ_DATA: begin
            axil4.s_axi_rvalid = 1'b1;
            axil4.s_axi_rdata  = register[addr];
        end
        default: begin
            axil4.s_axi_awready = 1'b0;
            axil4.s_axi_wready  = 1'b0;
            axil4.s_axi_arready = 1'b0;
        end
    endcase
end

// State transition logic
always_comb begin
    next_state = state;
    case (state)
        IDLE: begin
            if (axil4.s_axi_awvalid && axil4.s_axi_awready) begin
                next_state = WRITE_DATA;
            end else if (axil4.s_axi_arvalid && axil4.s_axi_arready) begin
                next_state = READ_DATA;
            end
        end
        WRITE_DATA: begin
            if (w_hs) begin
                next_state = WRITE_RESP;
            end
        end
        WRITE_RESP: begin
            if (b_hs) begin
                next_state = IDLE;
            end
        end
        READ_DATA: begin
            if (r_hs) begin
                next_state = IDLE;
            end
        end
        default: begin
            next_state = IDLE;
        end
    endcase
end

// FSM and register logic
integer i;
always_ff @(posedge aclk) begin
    if (!aresetn) begin
        state <= IDLE;
        for (i = 0; i < no_of_registers; i++) begin
            register[i] <= '0;
        end
    end else begin
        state <= next_state;

        // Latch address when write address handshake completes
        if (aw_hs) begin
            addr <= axil4.s_axi_awaddr;
        end
        
        // Register write logic when write data handshake completes
        if (w_hs) begin
            for (i = 0; i < (DATA_WIDTH/8); i++) begin
                if (axil4.s_axi_wstrb[i]) begin
                    register[addr][(i*8)+:8] <= axil4.s_axi_wdata[(i*8)+:8];
                end
            end
        end

        // Latch read address when read address handshake completes
        if (ar_hs) begin
            addr <= axil4.s_axi_araddr;
        end
    end
end

            
endmodule
