
interface xaxi4_lite_mif #(xaxi4_lite_pkg::xaxi4_lite_cfg_t C='{default: 0})
  (input logic aclk, aresetn);

  import  xaxi4_lite_pkg::*;
  
  `include "xaxi4_lite_mif.svh"

endinterface : xaxi4_lite_mif


interface xaxi4_lite_sif#(xaxi4_lite_pkg::xaxi4_lite_cfg_t C='{default: 0})
(input logic aclk, aresetn);

import  xaxi4_lite_pkg::*;

`include "xaxi4_lite_sif.svh"

endinterface : xaxi4_lite_sif


interface xaxi4_lite_if#(xaxi4_lite_pkg::xaxi4_lite_cfg_t C='{default: 0})
(input logic aclk, aresetn);

import  xaxi4_lite_pkg::*;

`include "xaxi4_lite_mif.svh"
`include "xaxi4_lite_sif.svh"

assign s_axi_awaddr = m_axi_awaddr; 
assign s_axi_awprot = m_axi_awprot; 
assign s_axi_awvalid = m_axi_awvalid;
assign m_axi_awready = s_axi_awready;
assign s_axi_wdata  = m_axi_wdata ;
assign s_axi_wstrb  = m_axi_wstrb ;
assign s_axi_wvalid = m_axi_wvalid;
assign m_axi_wready = s_axi_wready;
assign m_axi_bresp  = s_axi_bresp ;
assign m_axi_bvalid = s_axi_bvalid;
assign s_axi_bready = m_axi_bready;
assign s_axi_araddr = m_axi_araddr;
assign s_axi_arprot = m_axi_arprot;
assign s_axi_arvalid = m_axi_arvalid;
assign m_axi_arready = s_axi_arready;
assign m_axi_rdata  = s_axi_rdata ;
assign m_axi_rresp  = s_axi_rresp ;
assign m_axi_rvalid = s_axi_rvalid;
assign s_axi_rready = m_axi_rready;


endinterface : xaxi4_lite_if

