

package xaxi4_lite_pkg;

typedef struct packed {
    int A; 
    int N;
    int I; 
    int USE_STRB;
    int USE_PROT;
    int USE_MOD_PORT;
}  xaxi4_lite_cfg_t;


// LUT Configuration Struct
typedef struct packed {
    int unsigned w;                // Column width
    int unsigned d;                // Depth
    bit          pipe;      // Low latency mode (1) or High performance mode (0)
    // string       file;        // Initialization file
    bit          init;             // Enable initialization (default 0)
} lut_cfg_t;

endpackage :  xaxi4_lite_pkg