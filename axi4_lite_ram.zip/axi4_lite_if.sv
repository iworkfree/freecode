
interface axi4_lite_if #(xaxi4_lite_pkg::axi4_lite_cfg_t C='{default: 0})
( input aclk
, input aresetn
);
import axi4_lite_pkg::*;
  // ---------------------------------------------------------------------------
  logic [    C.A-1:0] araddr ;
  logic               arready;
  logic               arvalid;
  logic [    C.A-1:0] awaddr ;
  logic               awready;
  logic               awvalid;
  logic               bready ;
  logic [        1:0] bresp  ;
  logic               bvalid ;
  logic [(8*C.N)-1:0] rdata  ;
  logic               rready ;
  logic [        1:0] rresp  ;
  logic               rvalid ;
  logic [(8*C.N)-1:0] wdata  ;
  logic               wready ;
  logic               wvalid ;

  // ---------------------------------------------------------------------------
  logic [C.N-1:0] wstrb;

  generate
    if(C.USE_STRB == 0)
    begin : strb
      assign wstrb = 0;
    end
  endgenerate

  // ---------------------------------------------------------------------------
  logic [2:0] arprot;
  logic [2:0] awprot;

  generate
    if(C.USE_PROT == 0)
    begin : prot
      assign arprot = 0;
      assign awprot = 0;
    end
  endgenerate

  // ---------------------------------------------------------------------------
/* verilator lint_off ASCRANGE */
  logic [C.I-1:0] arid;
  logic [C.I-1:0] awid;
  logic [C.I-1:0] bid ;
  logic [C.I-1:0] rid ;
  logic [C.I-1:0] wid ;
/* verilator lint_on ASCRANGE */

  generate
    if(C.I < 1)
    begin : id
      assign arid = 0;
      assign awid = 0;
      assign bid  = 0;
      assign rid  = 0;
      assign wid  = 0;
    end
  endgenerate

  // // ---------------------------------------------------------------------------
  // clocking cb_s @(posedge aclk);
    // input   araddr;
    // input   awid;
    // output  arready;
    // input   arvalid;
    // input   awaddr;
    // output  awready;
    // input   awvalid;
    // input   bready;
    // output  bid;
    // output  bresp;
    // output  bvalid;
    // output  rdata;
    // output  rid;
    // input   rready;
    // output  rresp;
    // output  rvalid;
    // input   wdata;
    // input   wid;
    // output  wready;
    // input   wstrb;
    // input   wvalid;
    // input   aresetn;
    // input   aclk;
  // endclocking

  // ---------------------------------------------------------------------------
  // synthesis translate_off
  generate initial
  begin : initial_check
    $display("@@@ | [%8t] | %m | initial IDs | awaddr :%0x | bresp :%0x | wdata :%0x | wstrb :%0x"
            , $time, awaddr, bresp, wdata, wstrb);

    $display("@@@ | [%8t] | %m | initial IDs | arid :%0x | awid :%0x | bid :%0x | rid :%0x | wid :%0x"
            , $time, arid, awid, bid, rid, wid);

    $display("@@@ | [%8t] | %m | initial IDs | arprot :%0x | awprot", $time, arprot, awprot);
  end
  endgenerate

  always_comb if(~aresetn & (arvalid | awvalid | bvalid | rvalid | wvalid))
    $warning("!!! | [%8t] valid asserted during reset!", $time);

  always_ff @(posedge aclk) if(aresetn === 'x)
    $error("!!! | [%8t] | %m | aresetn === x", $time);

  // synthesis translate_on
  // ---------------------------------------------------------------------------

// -----------------------------------------------------------------------------
endinterface
