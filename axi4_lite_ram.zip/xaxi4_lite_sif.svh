

  logic [    C.A-1:0] s_axi_araddr ;
  logic               s_axi_arready;
  logic               s_axi_arvalid;
  logic [2:0]      s_axi_arprot;

  logic [    C.A-1:0] s_axi_awaddr ;
  logic               s_axi_awready;
  logic               s_axi_awvalid;
  logic [2:0]      s_axi_awprot;

  logic               s_axi_bready ;
  logic [        1:0] s_axi_bresp  ;
  logic               s_axi_bvalid ;

  logic [(8*C.N)-1:0] s_axi_rdata  ;
  logic               s_axi_rready ;
  logic [        1:0] s_axi_rresp  ;
  logic               s_axi_rvalid ;
  logic               s_axi_rready ;

  logic [(8*C.N)-1:0] s_axi_wdata  ;
  logic               s_axi_wready ;
  logic               s_axi_wvalid ;
  logic [C.N-1:0]     s_axi_wstrb  ;

  // assign axil4.s_axi_awaddr  = s_axi_awaddr ;
  // assign axil4.s_axi_awprot  = s_axi_awprot ;
  // assign axil4.s_axi_awvalid = s_axi_awvalid;
  // assign s_axi_awready = axil4.s_axi_awready;
  // assign axil4.s_axi_wdata   = s_axi_wdata  ;
  // assign axil4.s_axi_wstrb   = s_axi_wstrb;
  // assign axil4.s_axi_wvalid  = s_axi_wvalid ;
  // assign s_axi_wready = axil4.s_axi_wready;
  // assign s_axi_bresp  = axil4.s_axi_bresp ;
  // assign s_axi_bvalid = axil4.s_axi_bvalid;
  // assign axil4.s_axi_bready = s_axi_bready ;
  // assign axil4.s_axi_araddr  = s_axi_araddr ;
  // assign axil4.s_axi_arprot  = s_axi_arprot ;
  // assign axil4.s_axi_arvalid = s_axi_arvalid;
  // assign s_axi_arready = axil4.s_axi_arready;
  // assign s_axi_rdata  = axil4.s_axi_rdata ;
  // assign s_axi_rresp  = axil4.s_axi_rresp ;
  // assign s_axi_rvalid = axil4.s_axi_rvalid;
  // assign axil4.s_axi_rready = s_axi_rready ;
  
