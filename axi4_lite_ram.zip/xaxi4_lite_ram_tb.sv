


module top();


  import  xaxi4_lite_pkg::*;


//Step 2 - Import two required packages: axi_vip_pkg and <component_name>_pkg.
  import axi4lite_m_vip_pkg::*;
  // import axi_vip_pkg::*;
  
// Step 3 - Declare the agent for the master VIP
  axi4lite_m_vip_mst_t      master_agent;

  axi4lite_m_vip axi4lite_m_vip (.*);
  // --------------------------------------------------------------------
  bit aresetn = 0;
  bit aclk;
  initial forever #(10ns/2) aclk = ~aclk;

  // --------------------------------------------------------------------
  localparam A       = 32;
  localparam N       = 4; //! 4;
  localparam CLOG2_W = 4;

  //TODO 
  localparam w = 16; 
  localparam d = 32; 
  localparam pipe = 1; 
  

  // --------------------------------------------------------------------
  // localparam axi4_lite_cfg_t C = '{default: 0, A: A, N: N};
   localparam xaxi4_lite_cfg_t C = '{default: 0, A: A, N: N};
  // localparam       lut_cfg_t L = '{default: 0, w: w, d: d, pipe:pipe};
  // axi4_lite_if #(C) axi4_s(.*);

  xaxi4_lite_if #(C) axil4(.*);

  //include "axi4_lite_piker_bfm.svh"
   `include "xaxi4_lite_mif.svh"

  // --------------------------------------------------------------------
  // axi4_lite_ram #(.L(L)) r_if(.*);          //? do I need to send in the AXI4 config for the slave? 
                                        //? how does it know the size of the axi4 slave?
  
  axi4_lite_ram  #(C) r_if(.*);          //? do I need to send in the AXI4 config for the slave? 
                                        //? how does it know the size of the axi4 slave?

  // --------------------------------------------------------------------
   initial
   begin
    #10us;
    $warning("[%8t] Timeout!...", $time);
    //$finish;
   end

   
  
  // --------------------------------------------------------------------
  /* verilator lint_off UNUSEDSIGNAL */
  bit [(C.N*8)-1:0] data;
  /* verilator lint_on UNUSEDSIGNAL */

  initial
  begin
    // ........................................................................
    $display("[%8t] Model running...", $time);

    repeat(20) @(posedge aclk);
    aresetn = 1;
    $display("[%8t] reset deasserted...", $time);

    repeat(8) @(posedge aclk);

    //axi4_lite_write('h04, 'habba_beef);
    //axi4_lite_read ('h04, data       );
    //axi4_lite_read ('h08, data       );
    // axi4_lite_write('h04, 'habba_beef);
    // axi4_lite_read ('h04, data       );
    // axi4_lite_read ('h04, data       );
    // axi4_lite_read ('h3c, data       );
    // axi4_lite_read ('h04, data       );
    // axi4_lite_write('h04, 'habcd_1234);
    // axi4_lite_read ('h04, data       );

    
  end


  
// Step 4 - Create a new agent

    // Define transaction variables
  bit [31:0]  addr;
  bit [2:0]  prot;
  bit [31:0] wr_data;
  bit [31:0] rd_data;
  bit resp;
  // Test sequences
  initial begin
    // Create the master agent
    master_agent = new("master_vip_agent", axi4lite_m_vip.inst.IF);
    master_agent.set_agent_tag("Master VIP");
    //master_agent.set_verbosity(400);
    master_agent.start_master();
    repeat(8) @(posedge aclk);

    // --- Perform a write transaction ---
    addr = 32'h4;
    prot = 3'b0;
    wr_data = 32'hDEADBEEF;

    $display("Test: Performing AXI4-Lite write to address 0x%h with data 0x%h", addr, wr_data);
    master_agent.AXI4LITE_WRITE_BURST(addr, prot, wr_data, resp);

    repeat(8) @(posedge aclk);

    // --- Perform a read transaction ---
    addr = 32'h4;

    $display("Test: Performing AXI4-Lite read from address 0x%h", addr);
    master_agent.AXI4LITE_READ_BURST(addr, prot, rd_data, resp);
    $display("Test: Performing AXI4-Lite read from address 0x%h and data is 0x%h", addr, rd_data);

    repeat(8) @(posedge aclk);

    // --- Perform a write transaction ---
    addr = 32'h8;
    prot = 3'b0;
    wr_data = 32'hDEADBEEF;

    $display("Test: Performing AXI4-Lite write to address 0x%h with data 0x%h", addr, wr_data);
    master_agent.AXI4LITE_WRITE_BURST(addr, prot, wr_data, resp);

    repeat(8) @(posedge aclk);
  end


endmodule 