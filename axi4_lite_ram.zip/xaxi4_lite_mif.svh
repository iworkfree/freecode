

  logic [    C.A-1:0] m_axi_araddr ;
  logic               m_axi_arready;
  logic               m_axi_arvalid;
  logic [2:0]      m_axi_arprot;

  logic [    C.A-1:0] m_axi_awaddr ;
  logic               m_axi_awready;
  logic               m_axi_awvalid;
  logic [2:0]      m_axi_awprot;

  logic               m_axi_bready ;
  logic [        1:0] m_axi_bresp  ;
  logic               m_axi_bvalid ;

  logic [(8*C.N)-1:0] m_axi_rdata  ;
  logic               m_axi_rready ;
  logic [        1:0] m_axi_rresp  ;
  logic               m_axi_rvalid ;
  logic               m_axi_rready ;

  logic [(8*C.N)-1:0] m_axi_wdata  ;
  logic               m_axi_wready ;
  logic               m_axi_wvalid ;
  logic [C.N-1:0]     m_axi_wstrb  ;

  assign axil4.m_axi_awaddr  = m_axi_awaddr ;
  assign axil4.m_axi_awprot  = m_axi_awprot ;
  assign axil4.m_axi_awvalid = m_axi_awvalid;
  assign m_axi_awready = axil4.m_axi_awready;
  assign axil4.m_axi_wdata   = m_axi_wdata  ;
  assign axil4.m_axi_wstrb   = m_axi_wstrb;
  assign axil4.m_axi_wvalid  = m_axi_wvalid ;
  assign m_axi_wready = axil4.m_axi_wready;
  assign m_axi_bresp  = axil4.m_axi_bresp ;
  assign m_axi_bvalid = axil4.m_axi_bvalid;
  assign axil4.m_axi_bready = m_axi_bready ;
  assign axil4.m_axi_araddr  = m_axi_araddr ;
  assign axil4.m_axi_arprot  = m_axi_arprot ;
  assign axil4.m_axi_arvalid = m_axi_arvalid;
  assign m_axi_arready = axil4.m_axi_arready;
  assign m_axi_rdata  = axil4.m_axi_rdata ;
  assign m_axi_rresp  = axil4.m_axi_rresp ;
  assign m_axi_rvalid = axil4.m_axi_rvalid;
  assign axil4.m_axi_rready = m_axi_rready ;
  